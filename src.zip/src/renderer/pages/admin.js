// src/renderer/pages/admin.js
export async function mountAdmin () {
  const btnReset = document.getElementById('btnResetDb')
  const msg = document.getElementById('adminMsg')

  const locCsvFile = document.getElementById('locCsvFile')
  const locCsvName = document.getElementById('locCsvName')
  const btnImportLocCsv = document.getElementById('btnImportLocCsv')
  const adminToolsMsg = document.getElementById('adminToolsMsg')

  const btnOpenEmployeesModal = document.getElementById('btnOpenEmployeesModal')
  const btnCloseEmployeesModal = document.getElementById(
    'btnCloseEmployeesModal'
  )
  const employeesModal = document.getElementById('employeesModal')

  const employeesTbody = document.getElementById('employeesTbody')
  const employeesMsg = document.getElementById('employeesMsg')

  const btnOpenLocationsModal = document.getElementById('btnOpenLocationsModal')
  const btnCloseLocationsModal = document.getElementById(
    'btnCloseLocationsModal'
  )
  const locationsModal = document.getElementById('locationsModal')

  const btnOpenReceivesModal = document.getElementById('btnOpenReceivesModal')
  const btnCloseReceivesModal = document.getElementById('btnCloseReceivesModal')
  const receivesModal = document.getElementById('receivesModal')

  const setMsg = (t, err = false) => {
    if (!msg) return
    msg.textContent = t || ''
    msg.classList.toggle('err', !!err)
  }

  const setToolsMsg = (t, err = false) => {
    if (!adminToolsMsg) return
    adminToolsMsg.textContent = t || ''
    adminToolsMsg.classList.toggle('err', !!err)
  }

  const setEmployeesMsg = (t, err = false) => {
    if (!employeesMsg) return
    employeesMsg.textContent = t || ''
    employeesMsg.classList.toggle('err', !!err)
  }

  const escapeHtml = value =>
    String(value ?? '').replace(/[&<>"']/g, ch => {
      switch (ch) {
        case '&':
          return '&amp;'
        case '<':
          return '&lt;'
        case '>':
          return '&gt;'
        case '"':
          return '&quot;'
        case "'":
          return '&#39;'
        default:
          return ch
      }
    })

  const renderEmployees = rows => {
    if (!employeesTbody) return

    if (!Array.isArray(rows) || rows.length === 0) {
      employeesTbody.innerHTML = `
      <tr>
        <td colspan="3" class="muted">No employees found.</td>
      </tr>
    `
      return
    }

    employeesTbody.innerHTML = rows
      .map(row => {
        const isActive = Number(row?.is_active) === 1
        const statusText = isActive ? 'Active' : 'Inactive'

        return `
        <tr ${isActive ? '' : 'style="opacity:.55"'}>
          <td>${escapeHtml(row?.name)}</td>
          <td>${statusText}</td>
          <td>
            <span class="muted">Actions next</span>
          </td>
        </tr>
      `
      })
      .join('')
  }

  const loadEmployees = async () => {
    setEmployeesMsg('')

    try {
      const rows = await window.api.employeesList()
      renderEmployees(rows || [])
    } catch (e) {
      renderEmployees([])
      setEmployeesMsg(e?.message || 'Failed to load employees.', true)
    }
  }

  const openModal = el => {
    if (!el) return
    el.style.display = 'flex'
  }

  const closeModal = el => {
    if (!el) return
    el.style.display = 'none'
  }

  wireModal({
    openBtn: btnOpenEmployeesModal,
    closeBtn: btnCloseEmployeesModal,
    modal: employeesModal
  })

  if (btnOpenEmployeesModal && employeesModal) {
    btnOpenEmployeesModal.addEventListener('click', async () => {
      await loadEmployees()
    })
  }

  wireModal({
    openBtn: btnOpenEmployeesModal,
    closeBtn: btnCloseEmployeesModal,
    modal: employeesModal
  })

  wireModal({
    openBtn: btnOpenLocationsModal,
    closeBtn: btnCloseLocationsModal,
    modal: locationsModal
  })

  wireModal({
    openBtn: btnOpenReceivesModal,
    closeBtn: btnCloseReceivesModal,
    modal: receivesModal
  })

  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return
    closeModal(employeesModal)
    closeModal(locationsModal)
    closeModal(receivesModal)
  })

  // ---- Reset DB ----
  if (btnReset) {
    btnReset.addEventListener('click', async () => {
      setMsg('')
      const ok = confirm(
        'Wipe local database and restart? This cannot be undone.'
      )
      if (!ok) return

      try {
        await window.api.dbReset()
        setMsg('Reset requested…')
      } catch (e) {
        setMsg(e?.message || 'Reset failed.', true)
      }
    })
  }

  // ---- Locations CSV Import ----
  if (locCsvFile && locCsvName && btnImportLocCsv) {
    btnImportLocCsv.disabled = true
    locCsvName.textContent = 'No file selected'

    locCsvFile.addEventListener('change', () => {
      const f = locCsvFile.files && locCsvFile.files[0]
      locCsvName.textContent = f ? f.name : 'No file selected'
      btnImportLocCsv.disabled = !f
      setToolsMsg('')
    })

    btnImportLocCsv.addEventListener('click', async () => {
      setToolsMsg('')
      const f = locCsvFile.files && locCsvFile.files[0]
      if (!f) return

      try {
        btnImportLocCsv.disabled = true
        const csvText = await f.text()

        const res = await window.api.locationsImportCsv({ csvText })

        setToolsMsg(
          `Locations imported. Inserted: ${res?.inserted ?? 0}, Skipped: ${
            res?.skipped ?? 0
          }, Total: ${res?.total ?? 0}`
        )

        window.dispatchEvent(new CustomEvent('data:changed'))
      } catch (e) {
        setToolsMsg(e?.message || 'Locations import failed.', true)
      } finally {
        const f2 = locCsvFile.files && locCsvFile.files[0]
        btnImportLocCsv.disabled = !f2
      }
    })
  }
}
