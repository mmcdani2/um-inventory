﻿import { toCsv, downloadCsv } from "../utils/csv.js";

export async function mountItems() {
  const btnRefresh = document.getElementById("itemsRefresh");
  const btnAddRow = document.getElementById("btnAddRow");
  const btnImportCsv = document.getElementById("btnImportCsv");
  const btnTemplateCsv = document.getElementById("btnTemplateCsv");
  const fileInput = document.getElementById("csvFile");

  const btnMenu = document.getElementById("btnMenu");
  const menuPanel = document.getElementById("menuPanel");

  const tbody = document.querySelector("#itemsTable tbody");
  const hint = document.getElementById("itemsHint");
  const msg = document.getElementById("itemsMsg");

  let items = [];

  function setMsg(text, isError = false) {
    msg.textContent = text || "";
    msg.classList.toggle("err", !!isError);
  }

  function toggleMenu(open) {
    menuPanel.classList.toggle("hidden", !open);
  }

  btnMenu.addEventListener("click", (e) => {
    e.stopPropagation();
    toggleMenu(menuPanel.classList.contains("hidden"));
  });
  document.addEventListener("click", () => toggleMenu(false));
  menuPanel.addEventListener("click", (e) => e.stopPropagation());

  async function load() {
    items = await window.api.itemsList();
    tbody.innerHTML = items.map((i) => rowHtml(i)).join("");
    hint.textContent = items.length
      ? `${items.length} item(s)`
      : "No items yet.";
  }

  function addEditableRow() {
    setMsg("");
    if (tbody.querySelector("tr[data-new='1']")) return;

    const tr = document.createElement("tr");
    tr.dataset.new = "1";
    tr.innerHTML = newRowHtml();
    tbody.prepend(tr);

    // Select-all on focus for the add-row inputs (so you can click and type immediately).
    // For <input type="number">, select() can throw, so we fall back to clearing on first input.
    tr.querySelectorAll("input").forEach((input) => {
      const trySelectAll = () => {
        try {
          input.select();
          return true;
        } catch {
          return false;
        }
      };

      input.addEventListener("focus", () => {
        if (input.disabled || input.readOnly) return;
        // Defer so the click that focused the input doesn't clear selection/caret.
        setTimeout(() => {
          if (input.type === "number") {
            input.dataset.autoclear = "1";
          } else if (trySelectAll()) {
            input.dataset.autoselect = "1";
          } else {
            input.dataset.autoclear = "1";
          }
        }, 0);
      });

      input.addEventListener("mouseup", (e) => {
        if (input.dataset.autoselect === "1") {
          e.preventDefault();
          delete input.dataset.autoselect;
        }
      });

      input.addEventListener("keydown", (e) => {
        if (input.dataset.autoselect === "1") delete input.dataset.autoselect;

        if (input.dataset.autoclear === "1") {
          const isPrintable = e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey;
          if (isPrintable || e.key === "Backspace" || e.key === "Delete") {
            input.value = "";
            delete input.dataset.autoclear;
          }
        }
      });

      input.addEventListener("paste", () => {
        if (input.dataset.autoclear === "1") {
          input.value = "";
          delete input.dataset.autoclear;
        }
      });
    });

    tr.querySelector("input[name='sku']").focus();

    tr.querySelector("[data-cancel]").addEventListener("click", () =>
      tr.remove(),
    );

    tr.querySelector("[data-save]").addEventListener("click", async () => {
      setMsg("");
      const data = readRow(tr);

      try {
        await window.api.itemsCreate(data);
        setMsg("Added.");

        window.dispatchEvent(new CustomEvent("data:changed"));
        await load();
      } catch (e) {
        setMsg(e.message || "Failed to add item.", true);
      }
    });
  }

  function downloadTemplate() {
    const headers = [
      { key: "category", label: "Category" },
      { key: "sku", label: "SKU / Part #" },
      { key: "description", label: "Description" },
      { key: "unit", label: "Unit" },
      { key: "on_hand", label: "On Hand" },
      { key: "reorder_point", label: "Reorder Pt" },
      { key: "reorder_qty", label: "Reorder Qty" },
      { key: "cost", label: "Cost" },
      { key: "actions", label: "Actions" },
    ];

    const example = [
      {
        category: "Electrical",
        sku: "CAP-35-7.5",
        description: "35/5 MFD Run Capacitor",
        unit: "EA",
        on_hand: "0",
        reorder_point: "2",
        reorder_qty: "5",
        cost: "18.50",
        actions: "",
      },
    ];

    const csv = toCsv(example, headers);
    downloadCsv("items_import_template.csv", csv);
    toggleMenu(false);
  }

  btnTemplateCsv.addEventListener("click", downloadTemplate);

  btnImportCsv.addEventListener("click", () => {
    setMsg("");
    toggleMenu(false);
    fileInput.click();
  });

  fileInput.addEventListener("change", async () => {
    const f = fileInput.files?.[0];
    fileInput.value = "";
    if (!f) return;

    setMsg("");
    btnImportCsv.disabled = true;
    btnTemplateCsv.disabled = true;

    try {
      const text = await f.text();
      const { itemsToCreate } = parseItemsCsv(text);

      const res = await window.api.itemsImportCsv({ items: itemsToCreate });
      setMsg(`Imported ${Number(res?.imported ?? 0)} item(s).`);
      window.dispatchEvent(new CustomEvent("data:changed"));
      await load();
    } catch (e) {
      setMsg(e.message || "Failed to import CSV.", true);
    } finally {
      btnImportCsv.disabled = false;
      btnTemplateCsv.disabled = false;
    }
  });

  btnAddRow.addEventListener("click", addEditableRow);
  btnRefresh.addEventListener("click", load);
  window.addEventListener("data:changed", load);

  await load();
}

function rowHtml(i) {
  return `
    <tr data-id="${i.id}">
      <td>${esc(i.category)}</td>
      <td class="mono">${esc(i.sku)}</td>
      <td title="${esc(i.description)}">${esc(i.description)}</td>
      <td class="c">${esc(i.unit)}</td>
<td class="c mono">${num(i.on_hand_total)}</td>
<td class="c mono">${num(i.reorder_point)}</td>
<td class="c mono">${num(i.reorder_qty)}</td>
<td class="c mono">${money(i.default_cost)}</td>
<td class="c"></td>
    </tr>
  `;
}

function newRowHtml() {
  return `
    <td><input class="input input-mini" name="category" placeholder="Category" /></td>
    <td><input class="input input-mini mono" name="sku" placeholder="SKU*" /></td>
    <td><input class="input input-mini" name="description" placeholder="Description*" /></td>

    <td class="c"><input class="input input-mini ctext" name="unit" value="EA" /></td>
    <td class="c"><input class="input input-mini mono input-readonly ctext" value="—" disabled /></td>

    <td class="c"><input class="input input-mini ctext" name="reorder_point" inputmode="numeric" pattern="[0-9]*" value="0" /></td>
    <td class="c"><input class="input input-mini ctext" name="reorder_qty" inputmode="numeric" pattern="[0-9]*" value="0" /></td>

    <td class="c"><input class="input input-mini mono ctext" name="default_cost" inputmode="decimal" value="0.00" /></td>

    <td class="c">
      <div class="row-actions">
        <button class="btn btn-primary" data-save>Save</button>
        <button class="btn" data-cancel>Cancel</button>
      </div>
    </td>
  `;
}

function readRow(tr) {
  const v = (name) => tr.querySelector(`[name='${name}']`)?.value ?? "";
  return {
    sku: v("sku"),
    description: v("description"),
    category: v("category"),
    unit: v("unit") || "EA",
    reorder_point: v("reorder_point"),
    reorder_qty: v("reorder_qty"),
    default_cost: v("default_cost") || "0",
  };
}

function parseItemsCsv(csvText) {
  const expectedHeaders = [
    "Category",
    "SKU / Part #",
    "Description",
    "Unit",
    "On Hand",
    "Reorder Pt",
    "Reorder Qty",
    "Cost",
    "Actions",
  ];

  const rows = parseCsv(csvText).filter((r) =>
    r.some((c) => String(c ?? "").trim() !== ""),
  );
  if (rows.length === 0) throw new Error("CSV is empty.");

  const headerRow = rows[0].map((h) => normalizeHeader(h));
  const expectedNorm = expectedHeaders.map((h) => normalizeHeader(h));

  if (
    headerRow.length !== expectedNorm.length ||
    headerRow.some((h, i) => h !== expectedNorm[i])
  ) {
    throw new Error(
      `CSV headers must match Items table exactly:\n${expectedHeaders.join(", ")}`,
    );
  }

  const errors = [];
  const itemsToCreate = [];
  const seenSku = new Set();

  for (let i = 1; i < rows.length; i++) {
    const rowNum = i + 1; // 1-based in file
    const r = [...rows[i]];
    while (r.length < expectedHeaders.length) r.push("");
    if (r.length > expectedHeaders.length) {
      errors.push(`Row ${rowNum}: too many columns.`);
      continue;
    }

    const rowErrors = [];
    const [
      category,
      sku,
      description,
      unit,
      onHand,
      reorderPoint,
      reorderQty,
      cost,
      actions,
    ] = r.map((x) => String(x ?? "").trim());

    if (!sku) rowErrors.push(`Row ${rowNum}: SKU / Part # is required.`);
    if (!description) rowErrors.push(`Row ${rowNum}: Description is required.`);

    const skuKey = sku.toLowerCase();
    if (sku && seenSku.has(skuKey)) rowErrors.push(`Row ${rowNum}: duplicate SKU.`);
    if (sku) seenSku.add(skuKey);

    const onHandNum = parseOptionalNumber(onHand, rowNum, "On Hand", rowErrors);
    if (onHandNum !== null && onHandNum !== 0) {
      rowErrors.push(
        `Row ${rowNum}: On Hand must be blank or 0 (receive into a location instead).`,
      );
    }
    if (onHandNum !== null && !Number.isInteger(onHandNum)) {
      rowErrors.push(`Row ${rowNum}: On Hand must be a whole number.`);
    }

    const reorderPointNum = parseOptionalNumber(
      reorderPoint,
      rowNum,
      "Reorder Pt",
      rowErrors,
    );
    const reorderQtyNum = parseOptionalNumber(
      reorderQty,
      rowNum,
      "Reorder Qty",
      rowErrors,
    );
    const costNum = parseOptionalNumber(cost, rowNum, "Cost", rowErrors);

    if (reorderPointNum !== null && reorderPointNum < 0)
      rowErrors.push(`Row ${rowNum}: Reorder Pt must be >= 0.`);
    if (reorderPointNum !== null && !Number.isInteger(reorderPointNum))
      rowErrors.push(`Row ${rowNum}: Reorder Pt must be a whole number.`);
    if (reorderQtyNum !== null && reorderQtyNum < 0)
      rowErrors.push(`Row ${rowNum}: Reorder Qty must be >= 0.`);
    if (reorderQtyNum !== null && !Number.isInteger(reorderQtyNum))
      rowErrors.push(`Row ${rowNum}: Reorder Qty must be a whole number.`);
    if (costNum !== null && costNum < 0)
      rowErrors.push(`Row ${rowNum}: Cost must be >= 0.`);

    if (actions) rowErrors.push(`Row ${rowNum}: Actions must be blank.`);

    if (rowErrors.length) {
      errors.push(...rowErrors);
      continue;
    }

    itemsToCreate.push({
      __row: rowNum,
      sku,
      description,
      category,
      unit: unit || "EA",
      reorder_point: String(reorderPointNum ?? 0),
      reorder_qty: String(reorderQtyNum ?? 0),
      default_cost: String(costNum ?? 0),
    });
  }

  if (errors.length) {
    const preview = errors.slice(0, 10).join("\n");
    const more = errors.length > 10 ? `\n…plus ${errors.length - 10} more.` : "";
    throw new Error(`CSV validation failed:\n${preview}${more}`);
  }

  return { itemsToCreate };
}

function normalizeHeader(s) {
  return String(s ?? "")
    .replace(/^\uFEFF/, "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/\s*\/\s*/g, " / ");
}

function parseOptionalNumber(raw, rowNum, label, errors) {
  const s = String(raw ?? "").trim();
  if (!s) return null;
  const cleaned = s.replace(/[$,]/g, "");
  const x = Number(cleaned);
  if (!Number.isFinite(x)) {
    errors.push(`Row ${rowNum}: ${label} must be a number.`);
    return null;
  }
  return x;
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let inQuotes = false;

  const pushField = () => {
    row.push(field);
    field = "";
  };

  const pushRow = () => {
    pushField();
    rows.push(row);
    row = [];
  };

  const s = String(text ?? "");
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];

    if (inQuotes) {
      if (ch === '"') {
        const next = s[i + 1];
        if (next === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += ch;
      }
      continue;
    }

    if (ch === '"') {
      inQuotes = true;
      continue;
    }
    if (ch === ",") {
      pushField();
      continue;
    }
    if (ch === "\n") {
      pushRow();
      continue;
    }
    if (ch === "\r") continue;
    field += ch;
  }

  // finalize
  if (inQuotes) throw new Error("CSV parse error: unmatched quote.");
  if (field.length || row.length) pushRow();

  // drop trailing empty rows
  while (rows.length && rows[rows.length - 1].every((c) => String(c ?? "").trim() === "")) {
    rows.pop();
  }
  return rows;
}

function num(n) {
  const x = Number(n ?? 0);
  return Number.isFinite(x) ? x.toString() : "0";
}

function money(n) {
  const x = Number(n ?? 0);
  if (!Number.isFinite(x)) return "$0.00";
  return x.toLocaleString(undefined, { style: "currency", currency: "USD" });
}

function esc(s) {
  return String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
      })[c],
  );
}
